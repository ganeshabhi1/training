package com.example.demo;

import java.sql.Connection;

public interface MySQLConnection {
	public Connection getConnection();

}
